// myjs.js - Client-side validation for registration and edit forms

function validateForm(formId) {
    let form = document.getElementById(formId);
    let valid = true;
    let fname = form.firstname.value.trim();
    let sname = form.surname.value.trim();
    let phone = form.phone.value.trim();
    let dob = form.dob.value.trim();
    let address = form.address.value.trim();
    let email = form.email.value.trim();
    let password = form.password.value.trim();
    let event = form.querySelector('input[name="event"]:checked');

    // Clear previous error styles
    let fields = ["firstname", "surname", "phone", "dob", "address", "email", "password"];
    fields.forEach(f => {
        form[f].style.border = "1px solid #bfc6d0";
    });

    // First Name
    if (fname.length < 3) {
        form.firstname.style.border = "2px solid #f00";
        valid = false;
    }
    // Surname
    if (!sname) {
        form.surname.style.border = "2px solid #f00";
        valid = false;
    }
    // Phone
    if (!/^\d{8,15}$/.test(phone)) {
        form.phone.style.border = "2px solid #f00";
        valid = false;
    }
    // DOB
    if (!dob) {
        form.dob.style.border = "2px solid #f00";
        valid = false;
    }
    // Address
    if (!address) {
        form.address.style.border = "2px solid #f00";
        valid = false;
    }
    // Email
    if (!/^[\w\.-]+@[\w\.-]+\.\w+$/.test(email)) {
        form.email.style.border = "2px solid #f00";
        valid = false;
    }
    // Password
    if (password.length < 4) {
        form.password.style.border = "2px solid #f00";
        valid = false;
    }
    // Event
    if (!event) {
        alert("Please select an event type.");
        valid = false;
    }
    return valid;
}

// Example usage in form tag: <form id="regForm" onsubmit="return validateForm('regForm')">